# AI Prompt Log

## Prompt 1 — Chọn công cụ layout
> Khi một widget phải chiếm chính xác 2 hàng và 2 cột, xen kẽ với các widget nhỏ, nên dùng Grid hay Flexbox? Vì sao?

**Kết quả áp dụng:** Chọn CSS Grid; `.widget-hero` dùng `grid-column: span 2` và `grid-row: span 2`.

## Prompt 2 — Navbar responsive
> Làm sao để navbar Flexbox tự xuống dòng trên điện thoại mà không che logo?

**Kết quả áp dụng:** Dùng `display: flex`, `flex-wrap: wrap`, `gap`; nhóm menu có `flex-basis: 100%` ở màn hình nhỏ.

## Prompt 3 — Bootstrap Pricing
> Bootstrap 5 dùng lớp nào để có ba cột desktop và một cột mobile?

**Kết quả áp dụng:** Dùng `row g-4` và `col-12 col-md-4`; mỗi gói dùng `card` và `card-body`.
